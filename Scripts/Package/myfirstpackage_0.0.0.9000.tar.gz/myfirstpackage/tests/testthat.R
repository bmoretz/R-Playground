library(testthat)
library(myfirstpackage)

test_check("myfirstpackage")
